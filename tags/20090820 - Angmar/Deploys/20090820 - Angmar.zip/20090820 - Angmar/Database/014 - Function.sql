﻿update [Function] set Name = 'Insumos - Listar' where FullQualifiedName = 'Bagge.Seti.WebSite.ProductList' and Action = 'R'
update [Function] set Name = 'Insumos - Borrar' where FullQualifiedName = 'Bagge.Seti.WebSite.ProductList' and Action = 'D'
update [Function] set Name = 'Insumos - Crear' where FullQualifiedName = 'Bagge.Seti.WebSite.ProductEditor' and Action = 'C'
update [Function] set Name = 'Insumos - Editar' where FullQualifiedName = 'Bagge.Seti.WebSite.ProductEditor' and Action = 'U'
update [Function] set Name = 'Insumos - Ver' where FullQualifiedName = 'Bagge.Seti.WebSite.ProductEditor' and Action = 'R'
 
