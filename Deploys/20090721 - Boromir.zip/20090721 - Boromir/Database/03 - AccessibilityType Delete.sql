﻿delete AccessibilityType where Id = 4 

update AccessibilityType set Name = 'Sin Acceso' where Id = 1
update AccessibilityType set Name = 'Editar' where Id = 2
update AccessibilityType set Name = 'Ver' where Id = 3
