﻿insert into [Function] (Name, FullQualifiedName, Action) values ('Reporte - Historial de Ticket','Bagge.Seti.WebSite.Reports.TicketHistory', 'R')
