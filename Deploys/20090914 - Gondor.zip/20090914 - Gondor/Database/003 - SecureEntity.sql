﻿update SecureEntity
set ClassFullQualifiedName = ClassFullQualifiedName + ', Bagge.Seti.BusinessEntities' 

alter table SecureEntity drop column AssemblyName